n = int(input("Por favor ingrese un número:     "))
lista=[]
for i in range(1,11):
    n1=n*i
    lista.append(n*i)
print(lista)
