string = str(input("Ingrese una palabra:    "))
n = len(string)
lista=[]
for i in range(0,n):
    p1=string[i]
    lista.append(p1)
print(lista)