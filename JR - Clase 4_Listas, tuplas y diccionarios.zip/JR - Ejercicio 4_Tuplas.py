#Crea una tupla con números, pide un numero por teclado e indica cuantas veces se repite.
print("Bienvenido al sistema de operaciones de Tuplas de Joaquín Rodríguez")
tupla = (1,2,3,4,5,5,5,5,5,5,5,6,7,7,7,7,8,8,8,8,8,8,8)
cont = 0
n = int(input("Ingrese la posición de un número:   "))
b = tupla[n]
print("El número es",b)
v = tupla.count(b)
print("El número",b,"se repite",v,"veces")