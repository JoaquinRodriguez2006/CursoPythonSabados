tupla_meses = (1,2,3,4,5,6,7,8,9,10,11,12)
num_mes = int(input("Ingrese una posición:    "))
print(tupla_meses.index(num_mes))
if num_mes == 0:
    print("El programa ha terminado")
elif num_mes>12:
    print("ERROR")