dict = {}
frase = str(input("Ingrese una frase:   "))
n = len(frase)
lista_palabras=frase.split(" ")
print(lista_palabras)
c = len(lista_palabras)
for palabra in lista_palabras:
    if palabra in dict:
        dict[palabra]+=1
    else:
        dict[palabra]=1	

for campo,valor in dict.items():
	print (campo,":",valor)