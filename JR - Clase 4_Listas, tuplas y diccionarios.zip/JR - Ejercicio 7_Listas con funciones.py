frase = str(input("Tipee una frase: "))
lista_palabras=frase.split(" ")
print(lista_palabras)

def vocales():
    contador = 0
    for palabra in lista_palabras:
        for letra in palabra:
            if letra == "a":
                contador += 1
            if letra == "e":
                contador += 1
            if letra == "i":
                contador += 1
            if letra == "o":
                contador += 1
            if letra == "u":
                contador += 1
            print("Este es el contador de vocales:",contador)

def consonantes():
    contador2 = 0
    for palabra in lista_palabras:
        for letra in palabra:
            if letra != "a":
                contador2 += 1
            if letra != "e":
                contador2 += 1
            if letra != "i":
                contador2 += 1
            if letra != "o":
                contador2 += 1
            if letra != "u":
                contador2 += 1
                print("Este es el contador de consonantes:",contador2)

vocales()
consonantes()