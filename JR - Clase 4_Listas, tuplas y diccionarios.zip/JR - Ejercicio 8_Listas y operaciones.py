lista1 = []
lista2 = []
n = int(input("Ingrese un número de elementos de la lista:   "))
m = int(input("Ingrese un número de elementos de la lista:   "))
for i1 in range(0,n):
    lista1.append(i1)
print(lista1)
for i2 in range(0,m):
    lista2.append(i2)
print(lista2)

if n==m:
    suma = lista1+lista2
    print(suma)
#Necesité 2 FOR y 1 IF. Además, usé un input para pedir los números por teclado