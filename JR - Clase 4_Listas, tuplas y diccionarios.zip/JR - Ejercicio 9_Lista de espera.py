lista_de_espera = []
op = int(input("Presione 1 para entrar al menú y 2 para salir del menú: "))
while op==1:
    paciente = str(input("Ingrese el nombre del paciente:   "))
    lista_de_espera.append(paciente)
    print(lista_de_espera)
    print("Ingrese 1 para continuar: ")
    print("Ingrese 2 para eliminar un paciente de la lista")
    print("Ingrese 3 para eliminar un paciente atendido con urgencia")
    print("Ingrese 4 para determinar los pacientes antes de otro")
    op1 = int(input("Su opción: "))
    if op1==1:
        continue
    elif op1==2:
        pac = str(input("Ingrese el nombre del paciente:    "))
        lista_de_espera.remove(pac)
        print(lista_de_espera)
    elif op1==3:
        pac = str(input("Ingrese el nombre del paciente:    "))
        lista_de_espera.remove(pac)
        print(lista_de_espera)
    elif op1==4:
        pac = str(input("Ingrese el nombre del paciente:    "))
        n = lista_de_espera.index(pac)
        print(n)

if op==2:
    print("Salió de la Database")