n = int(input("Ingrese un número:   "))
def redondear():
    div = n%10
    if div>=5:
        RED = n//10
        sum = RED+1
        print(sum)
    elif div<5:
        RED2 = n//10
        print(RED2)

def redondear2(n:float) -> int:
    return round(n)

redondear2