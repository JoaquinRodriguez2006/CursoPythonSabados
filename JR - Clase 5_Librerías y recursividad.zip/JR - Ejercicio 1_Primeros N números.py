#CON INTERACIÓN

"""a = int(input("Ingrese un número:   "))

cont = 0

def sumar_números():
    for i in range(0,a):
        suma = cont+i
    print(suma)

sumar_números()"""

#CON RECURSIVIDAD
a = int(input("Ingrese un número:   "))
cont = 0

def sumar_con_recursividad(a):
    if a==0:
        return 0
    return a+sumar_con_recursividad(a-1)

print(sumar_con_recursividad(a))