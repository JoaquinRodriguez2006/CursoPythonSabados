import datetime

x = datetime.datetime.now()
print("La hora actual es:",x)