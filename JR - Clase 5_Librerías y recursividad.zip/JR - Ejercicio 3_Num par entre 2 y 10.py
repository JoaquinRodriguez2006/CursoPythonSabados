import random

for numero in range(2,10+1):
    div = numero%2
    if div == 0:
        número2 = numero
print(random.randint(número2,número2))