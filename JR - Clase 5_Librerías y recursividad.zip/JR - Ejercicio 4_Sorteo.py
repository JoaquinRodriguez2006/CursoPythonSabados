#Programa de sorteos
import random
#importar patticipiantes desde un lugar en la computadora (sugerencia)
print("Ingrese 1 para iniciar el programa")
print("Ingrese 2 para salir del programa")
op=str(input())

if op!=1:
    participantes = str(input("Ingrese el nombre y el apellido del participante: "))
    print("Ingrese 1 para ingresar participantes")
    print("Ingrese 2 para elegir un ganador")
    op2=str(input())
    if op2!=1:
        participantes = str(input("Ingrese el nombre y el apellido del participante: "))
    if op2!=2:
        print(random.choice(participantes))
elif op==2:
    print("Usted ha salido del programa de sorteos de Joaquín Rodríguez")