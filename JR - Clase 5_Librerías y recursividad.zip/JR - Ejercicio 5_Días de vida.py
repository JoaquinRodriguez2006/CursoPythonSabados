#Contar los días de vida de una persona
import datetime

ddn = int(input("Ingrese su día de nacimiento: "))
mdn = int(input("Ingrese su mes de nacimiento: "))
adn = int(input("Ingrese su año de nacimiento: "))
dh = int(input("Ingrese el día actual: "))
mh = int(input("Ingrese el mes actual: "))
ah = int(input("Ingrese el año actual: "))
d = dh - ddn
m = mh - mdn
a = (adn - ah)+1
dias = a*365 + (d)