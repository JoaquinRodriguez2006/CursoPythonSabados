#Bola Ocho
import random
print("Escriba su pregunta a continuación")
pregunta = str(input())
listaopciones = ["Es seguro que sí", "Las chances son buenas", "Puedes contar con ello", "Pregúntame de nuevo más tarde", "Concéntrate y pregunta de nuevo", "No veo con claridad, intenta de nuevo", "Mi respuesta es no", "Mis fuentes me dicen que no"]
print(random.choices(listaopciones))