# Asuma que input_file es el objeto archivo de un archivo de texto que fue abierto para lectura,
#  y output_file es el objeto archivo de un archivo de texto abierto para escritura. Explique el 
# contenido del archivo que fue escrito al ejecutar este código:
"""empty_str =''
line =input_file.readline() while (line !=empty_str):
output_file.write(line +'\n')
line =input_file.readline()"""

#Lo que hace es que lee el contenido que tiene el input_file, lo almacena en la variable line y luego lo reescribe
# en el output_file. Luego, empieza de vuelta. Va leyendo la línea mientras esa línea no está vacía.