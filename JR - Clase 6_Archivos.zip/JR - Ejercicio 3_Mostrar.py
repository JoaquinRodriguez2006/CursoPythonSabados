with open('/Users/joaquinrodriguez/Documents/Robótica 2021/Curso Python Sábados 15hs/Clase 6 - Archivos/Práctica/EJERCICIO3', 'r') as miArchivo:
    r = miArchivo.read()
print(r)