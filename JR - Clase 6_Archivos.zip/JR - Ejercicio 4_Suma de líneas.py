#Escriba una función sumaLineas(nombre_archivo) que lea un archivo de texto que 
#contiene exactamente un número en cada línea, y devuelva la suma de estos números.

def suma_lineas(Ej4sumar):
    with open('Ej4sumar.txt', 'r') as miArchivo:
        x = miArchivo.read()
        for linea in x:
            iden = x.index(linea)
            for numero in linea:
                sumar = numero+numero

suma_lineas("Ej4sumar.txt")