#Escriba un programa en Python que copie los contenidos de un archivo a otro archivo.
file = open("EJERCICIO3","r")
read = file.read()
file2 = open("Test","a")
file2.write(file.read())