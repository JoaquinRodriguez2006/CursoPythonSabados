def contar_caminos(entrada1,entrada2):
    if entrada1==1 or entrada2==1:
        return 1
    else:
        return contar_caminos(entrada1,entrada2-1) + contar_caminos(entrada1-1,entrada2)

if __name__ == '__main__':
    print(contar_caminos(3,2))