with open("EJERCICIO3","r") as F:
    print (F.readlines())
F.closed