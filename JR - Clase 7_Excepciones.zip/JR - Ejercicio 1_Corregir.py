#Para cada una de las siguientes funciones recursivas, indique por qué no están bien definidas. 

"""
def rfuncion1 (n):
    return n + rfuncion (n-1)"""

#

"""def rfuncion2 (n):
    if n==0::
        return 1
    return n + rfuncion2 (n+1)"""

#