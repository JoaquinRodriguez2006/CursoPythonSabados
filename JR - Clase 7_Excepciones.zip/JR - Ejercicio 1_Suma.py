def validar_valores(n1,n2):
    while True:
        try:
            n1 = int(input("Ingrese N1: "))
            n2 = int(input("Ingrese N2: "))
        except ValueError:
            print("Hubo un error de valor. Por favor, reinicie el programa")
        else:
            print(n1+n2)

validar_valores(2,2)