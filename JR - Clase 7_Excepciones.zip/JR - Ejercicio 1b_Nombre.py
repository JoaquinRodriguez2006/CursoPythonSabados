def comprobar():
    while True:
        try:
            n = str(input("Ha ocurrido un error. Ingrese su nombre otra vez:   "))
            break
        except ValueError:
            print("Ha ocurrido un error")

n = str(input("Ingrese su nombre:   "))
comprobar()