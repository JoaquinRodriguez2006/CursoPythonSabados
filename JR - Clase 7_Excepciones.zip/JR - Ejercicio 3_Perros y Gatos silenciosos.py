try:
    file = open("Perros.txt","r")
    file2 = open("Gatos.txt","r")
except FileNotFoundError:
    file = "Archivo no hallado"
    file2 = "Archivo no hallado"
else:
    print("")
    print(file.read())
    print("_________________________________")
    print("")
    print(file2.read())