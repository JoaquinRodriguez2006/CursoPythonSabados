try:
    file = open("Perros.txt","r")
    file2 = open("Gatos.txt","r")
except FileNotFoundError:
    print("Intente mover el archivo a su directorio")
else:
    print("")
    print(file.read())
    print("_________________________________")
    print("")
    print(file2.read())