file = open("/Users/joaquinrodriguez/Documents/Robótica 2021/Curso Python Sábados 15hs/Clase 7 - Errors/Mis números favoritos.txt","r")
print(file.read())
try:
    file = open("Mis números favoritos.txt","w")
    n=str(input("Ingrese lo que quiera escribir. Si no quiere escribir,'ENTER':    "))
    file.write(n)
except FileNotFoundError:
    print("No sé que decirle...")