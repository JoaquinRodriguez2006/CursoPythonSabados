#Escriba un programa que pida al usuario su nombre. Cuando este lo ingrese, muestre un 
#mensaje de bienvenida en la pantalla, y agregue una línea donde registre la visita del usuario a
#un archivo llamado libro_invitados.txt. Asegúrese de que cada registro figure en una nueva línea, 
#y de que cada nueva entrada sea grabada en el mismo archivo, incluso entre múltiples ejecuciones del programa.

nombre = str(input("Ingrese su nombre:  "))
print("------------------------------------")
print("BIENVENIDO AL LIBRO DE INVITADOS")
file = open("Librodevisitas","a")
file.append(nombre)