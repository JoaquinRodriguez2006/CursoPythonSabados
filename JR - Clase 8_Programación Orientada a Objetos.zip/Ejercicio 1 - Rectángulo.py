class Rectangulo():
    def __init__(self,base,altura,color):
        self.base = base
        self.altura = altura
        self.color = color

    def area(self):
        return (self.base * self.altura)

rect = Rectangulo(10,5,"verde")
print(rect.area()) #accedemos a los objetos con "nombre del objeto" , "." , "sus atributos"