#OBJETO MATE

class Mate():
    def __init__(self,cebadas=5,estado="vacío",cebadas_maximas="7"):
        self.cebadas = cebadas
        self.estado = estado
        self.cebadas_maximas = cebadas_maximas

    def cebar(self,poner_agua):
        self.poner_agua = poner_agua
        print("Llenando mate")
        if self.estado == "lleno":
            print("¡Cuidado! ¡Te quemaste!")
        elif self.estado == "vacío":
            print("Prosigo con la llenada")

    def beber(self,cebadas_maximas):
        self.estado == "vacio"
        x = cebadas_maximas-1
        print("El mate está ahora vacío y le quedan",x,"cebadas disponibles")

    def cebadas_extra(self,cebadas_maximas):
        if cebadas_maximas == 0:
            print("¡Atención! El mate está lavado")

#LLAMO OBJETO "MATE"
argentino = Mate(5,"lleno",10)

"""print(argentino.cebar(4))
print(argentino.beber(10))
print(argentino.cebadas_extra(0))
"""
