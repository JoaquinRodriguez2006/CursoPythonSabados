class corcho():
    def __init__(self,bodega="Desconocida"):
        self.bodega = bodega
        print(bodega)

class botella():
    def __init__(self,bodega,estado):
        self.bodega = bodega
        self.estado = estado
        if self.estado == "Destapado":
            corcho == "Tapado"
            print("Su corcho de la bodega",bodega,"está ahora tapado")
        elif self.estado == "tapado":
            print("Su corcho de la bodega",bodega,"está tapado")

class sacacorchos():
    def __init__(self,bodega,corchos,botellas):
        self.bodega = bodega
        self.corchos = corchos
        self.botellas = botellas
    
    def destapar(self,estado_destapador):
        self.estado_destapador = estado_destapador
        if botella == "Tapada":
            botella == "Destapada"
            corcho == self.corcho
        elif botella == "Destapada":
            print("Su botella ya está destapada")
        elif estado_destapador == "LLENO":
            print("Disulpe las molestias. El sacacorcho está lleno")
            estado_destapador == "Listo para usar"
            print("Sacacorcho destapado y listo para usar")

    def limpiar(self,estado_destapador):
        if estado_destapador == "Lleno":
            estado_destapador == "Listo para usar"
            print("Sacacorcho destapado y listo para usar")
        elif estado_destapador == "Listo para usar":
            print("El sacacorchos está listo para usar")
    
c = corcho("Malbec")
b = botella("Malbec","Tapado")
sc = sacacorchos("Malbec","Malbec","Tapada")